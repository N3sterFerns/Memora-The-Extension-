const saveBtn = document.getElementById("saveBtn");
const statusDiv = document.getElementById("status");
const dashboardContainer = document.getElementById("dashboardContainer");
const openDashboardBtn = document.getElementById("openDashboard");

const pageTitleDiv = document.getElementById("pageTitle");
const pageUrlDiv = document.getElementById("pageUrl");

let isSaving = false;

function showStatus(message, type) {
  statusDiv.textContent = message;
  statusDiv.className = `status ${type}`;
}

function setLoading(isLoading) {
  saveBtn.disabled = isLoading;
  saveBtn.classList.toggle("loading", isLoading);
  isSaving = isLoading;
}

// Open dashboard
openDashboardBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: "https://memora-wine.vercel.app/dashboard" }); 
});

saveBtn.addEventListener("click", async () => {
  if (isSaving) return;
  setLoading(true);
  showStatus("Saving...", "info");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  const url = tab.url;
  const title = tab.title;

  chrome.storage.local.get(["token"], async (result) => {
    const token = result.token;

    if (!token) {
      showStatus("Please login first", "error");
      setLoading(false);
      return;
    }

    try {
      const res = await fetch("https://memora-backend-6z7o.onrender.com/api/save", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ url, title }),
      });

      if (res.ok) {
        showStatus("Saved successfully ✓", "success");
        dashboardContainer.classList.remove("hidden");

        pageTitleDiv.textContent = title;
        pageUrlDiv.textContent = url;

        pageTitleDiv.parentElement.style.display = "block";

        // Hide it after 30 seconds
        setTimeout(() => {
          pageTitleDiv.parentElement.style.display = "none";
        }, 30000);
      } else {
        showStatus("Failed to save", "error");
      }
    } catch (err) {
      console.error(err);
      showStatus("Network error", "error");
    } finally {
      setLoading(false);
    }
  });
});
chrome.runtime.onMessage.addListener(
  (request, sender, sendResponse) => {
    if (request.type === "SET_TOKEN") {
      chrome.storage.local.set({ token: request.token }, () => {
        sendResponse({ status: "success" }); 
      });

      return true; 
    }
  }
);